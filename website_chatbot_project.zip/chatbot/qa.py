from langchain.chains import ConversationalRetrievalChain
from langchain_openai import ChatOpenAI

def get_qa_chain(vectorstore, memory):
    llm = ChatOpenAI(temperature=0)
    return ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=vectorstore.as_retriever(),
        memory=memory
    )
