import requests
from bs4 import BeautifulSoup

def scrape_website(url):
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except:
        return ""
    soup = BeautifulSoup(response.text, "html.parser")
    for tag in soup(["header","footer","nav","script","style","aside"]):
        tag.decompose()
    return soup.get_text(separator=" ")
