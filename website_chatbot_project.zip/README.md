# Website-Based Chatbot

This project is a student-built website-based chatbot created for the Humanli.ai AI/ML Engineer assessment.

## How to Run

1. Open folder in VS Code
2. Create virtual environment
3. Install requirements
4. Set OpenAI API key
5. Run Streamlit app

## Command
streamlit run app.py
