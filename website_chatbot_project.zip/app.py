import streamlit as st
from scraper.scraper import scrape_website
from processing.cleaner import clean_text
from processing.chunker import chunk_text
from embeddings.embedder import get_embeddings
from embeddings.vector_store import create_or_load_faiss
from chatbot.memory import get_memory
from chatbot.qa import get_qa_chain

st.set_page_config(page_title="Website Chatbot")
st.title("Website-Based Chatbot")

url = st.text_input("Enter Website URL")

if "qa_chain" not in st.session_state:
    st.session_state.qa_chain = None

if st.button("Index Website"):
    with st.spinner("Indexing website..."):
        raw_text = scrape_website(url)
        if raw_text.strip() == "":
            st.error("Could not extract content.")
        else:
            cleaned = clean_text(raw_text)
            chunks = chunk_text(cleaned)
            embeddings = get_embeddings()
            vectorstore = create_or_load_faiss(chunks, embeddings)
            memory = get_memory()
            st.session_state.qa_chain = get_qa_chain(vectorstore, memory)
            st.success("Website indexed successfully!")

question = st.text_input("Ask a question")

if st.button("Ask"):
    if st.session_state.qa_chain is None:
        st.warning("Please index a website first.")
    else:
        result = st.session_state.qa_chain({"question": question})
        answer = result["answer"]
        if answer.strip() == "":
            st.write("The answer is not available on the provided website.")
        else:
            st.write(answer)
