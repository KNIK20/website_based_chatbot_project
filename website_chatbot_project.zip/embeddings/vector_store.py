import os
from langchain_community.vectorstores import FAISS

def create_or_load_faiss(chunks, embeddings):
    path = "data/faiss_index"
    if os.path.exists(path):
        return FAISS.load_local(path, embeddings, allow_dangerous_deserialization=True)
    vectorstore = FAISS.from_texts(chunks, embeddings)
    vectorstore.save_local(path)
    return vectorstore
